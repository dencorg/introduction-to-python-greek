2 + 2
# 4

50 - 5*6
# 20

(50 - 5*6) / 4
# 5.0

8 / 5
# 1.6

17 / 3  # διαίρεση
# 5.666666666666667

17 // 3  # κρατά μόνο το ακέραιο μέρος
# 5

17 % 3  # υπόλοιπο
# 2

5 * 3 + 2
# 17

5 ** 2  # 5 στο τετράγωνο
# 25

width = 20
height = 5 * 9
width * height
# 900

result = width * height
print(result)

a = 5
b = 4
a > b
# True
not a > b
# False

a == 5
# True
a != 5
# False
a >= 5
# True

c = 6
a > b and a > c
# False
a > b and not a > c
# True

a > b or a > c
# True
a > b or a > c
# True
a > b or not a > c
# True
not a > b or not a > c
# True
not ( a > b ) or a > c
# False
not a > b or a > c
# False
